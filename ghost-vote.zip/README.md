# Ghost Vote

Run this to fix css
`npm run zip`

`gulp build`
