document.addEventListener("DOMContentLoaded", function () {
    const featuredUpdates =
        document.querySelectorAll(".updates-feed")[0].children.length;
    if (featuredUpdates < 6) {
        document.querySelector(".non-featured").style.display = "block";
    }
});

document.addEventListener("DOMContentLoaded", function () {
    const featuredUpdates =
        document.querySelectorAll(".issues-feed")[0].children.length;
    if (featuredUpdates < 6) {
        document.querySelector(".non-featured").style.display = "block";
    }
});

// Donation Metrics

document.addEventListener("DOMContentLoaded", function () {
    const metricsContainer = document.getElementById(
        "donationMetricsContainer"
    );
    const wantedMetrics = metricsContainer
        .getAttribute("data-metrics")
        .split(", ")
        .map((metric) => metric.trim());

    fetch("https://postgrest.bentleyhensel.com//donation_metrics")
        .then((response) => response.json())
        .then((data) => {
            const metrics = data[0];
            wantedMetrics.forEach((metric) => {
                if (metrics.hasOwnProperty(metric)) {
                    let metricDiv = document.createElement("div");
                    metricDiv.className = "metric";
                    metricDiv.textContent = `${metric.replace(/_/g, " ")}: ${
                        metrics[metric]
                    }`;
                    metricsContainer.appendChild(metricDiv);
                }
            });
        })
        .catch((error) => {
            console.error("Error fetching donation metrics:", error);
            metricsContainer.textContent = "Failed to load donation metrics";
        });
});
